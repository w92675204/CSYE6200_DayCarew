# DayCare Project
Students, Teachers, Classrooms, and Immunization Management

# Group Members

- Jiawei Qian
- Chunzheng Wen
- Jiao He
- Fangyu Wu
- Zifeng Xu
- Siyan Li
- Ching-Fong Chen
- Yi-Chen Yi

# Environment

- Apache Netbeans 12.5
- JDK 1.8
