package Model;

public abstract class AbstractFactory {

}
