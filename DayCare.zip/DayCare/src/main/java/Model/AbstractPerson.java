package Model;

public abstract class AbstractPerson {
    public abstract int getId();
    public abstract void setId(int id);
    public abstract void setAge(int age);
    public abstract int getAge();
    //public abstract void setName(String name);
    public abstract String getFirstName();
    public abstract String getLastName();

}
